import { Calculator } from "lucide-react";
import { SimpleConfig } from "@/components/calculator/SimpleConfig";
import { SimpleResults } from "@/components/calculator/SimpleResults";
import { useCalculator } from "@/hooks/useCalculator";

export default function CalculatorPage() {
  const { state, results, updateState } = useCalculator();

  return (
    <div className="min-h-screen p-4 lg:p-8 bg-slate-50">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-800 mb-2 flex items-center">
            <Calculator className="text-green-600 mr-3 h-8 w-8" />
            Calculadora de Lucro - Worldshards
          </h1>
          <p className="text-slate-600">
            Configure seus investimentos e calcule o lucro líquido final após recompra das gemas.
          </p>
        </div>

        {/* Main Calculator Section */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 mb-8">
          {/* Configuration Panel */}
          <div>
            <SimpleConfig state={state} onUpdate={updateState} />
          </div>

          {/* Results Summary */}
          <div>
            <SimpleResults results={results} />
          </div>
        </div>

        {/* Example Data Footer */}
        <div className="bg-blue-50 rounded-xl border border-blue-200 p-6 mb-8">
          <h3 className="text-lg font-semibold text-blue-800 mb-3">
            Dados de Exemplo (seus dados reais):
          </h3>
          <div className="text-sm text-blue-700 space-y-1">
            <div>• Investimento: $100 USD = 14.000 gems</div>
            <div>• Gems restantes: 443</div>
            <div>• Gems consumidas: 13.557</div>
            <div>• Tokens dos equipamentos: 1.096</div>
            <div>• Tokens farmados: 4.566 (com 84 cargas)</div>
            <div>• Total de tokens: 5.662</div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center text-slate-600">
          <p className="text-sm">
            Calculadora focada no lucro líquido final para reinvestimento em Worldshards
          </p>
        </div>
      </div>
    </div>
  );
}
