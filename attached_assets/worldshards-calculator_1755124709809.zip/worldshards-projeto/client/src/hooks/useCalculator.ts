import { useState, useMemo } from "react";
import { CalculatorState, CalculationResults } from "@/types/calculator";
import { calculateResults } from "@/lib/calculations";

const initialState: CalculatorState = {
  investimentoInicial: 100, // $100 USD
  gemasIniciais: 14000, // 14000 gems compradas
  gemasRestantes: 443, // Gems que sobraram
  totalConsumido: 13557, // 13557 gems gastas (14000-443)
  totalTokensGerados: 1096, // 1096 tokens dos equipamentos
  tokensFarmados: 4566, // 4566 tokens farmados
  cargasUtilizadas: 84, // 84 cargas usadas no farm
  precoToken: 0.042, // Preço do token
  precoGema: 0.0071 // Preço da gema
};

export function useCalculator() {
  const [state, setState] = useState<CalculatorState>(initialState);

  const results: CalculationResults = useMemo(() => {
    return calculateResults(state);
  }, [state]);

  const updateState = (updates: Partial<CalculatorState>) => {
    setState(prev => ({ ...prev, ...updates }));
  };



  return {
    state,
    results,
    updateState
  };
}
