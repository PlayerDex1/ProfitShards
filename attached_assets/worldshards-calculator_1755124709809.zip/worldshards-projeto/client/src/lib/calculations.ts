import { CalculatorState, CalculationResults } from "@/types/calculator";

export function calculateResults(state: CalculatorState): CalculationResults {
  const {
    investimentoInicial,
    gemasIniciais,
    gemasRestantes,
    totalConsumido,
    totalTokensGerados,
    tokensFarmados,
    cargasUtilizadas,
    precoToken,
    precoGema
  } = state;

  // Cálculos principais
  const tokensTotais = totalTokensGerados + tokensFarmados;
  const valorTotalTokens = tokensTotais * precoToken;
  const custoTotalGemas = totalConsumido * precoGema;
  const lucroLiquido = valorTotalTokens - custoTotalGemas;
  
  // Cálculo para recompra das gemas necessárias para nova aceleração
  const gemasNecessariasRecompra = totalConsumido; // Precisa das mesmas gemas para refazer
  const custoRecompra = gemasNecessariasRecompra * precoGema;
  const lucroFinal = lucroLiquido - custoRecompra;
  
  // Eficiência do farm (tokens por carga)
  const eficienciaFarm = cargasUtilizadas > 0 ? tokensFarmados / cargasUtilizadas : 0;

  return {
    valorTotalTokens,
    custoTotalGemas,
    lucroLiquido,
    tokensTotais,
    gemasNecessariasRecompra,
    custoRecompra,
    lucroFinal,
    eficienciaFarm
  };
}
