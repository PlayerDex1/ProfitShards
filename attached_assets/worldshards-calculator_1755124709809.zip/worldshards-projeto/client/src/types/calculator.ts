export interface CalculatorState {
  investimentoInicial: number; // USD investido
  gemasIniciais: number; // Gemas compradas com USD
  gemasRestantes: number; // Gemas que sobraram
  totalConsumido: number; // Gemas gastas nos equipamentos
  totalTokensGerados: number; // Tokens obtidos dos equipamentos
  tokensFarmados: number; // Tokens farmados usando as cargas
  cargasUtilizadas: number; // Total de cargas usadas no farm
  precoToken: number; // Preço atual do token em USD
  precoGema: number; // Preço atual da gema em USD
}

export interface CalculationResults {
  valorTotalTokens: number; // Valor dos tokens gerados + farmados
  custoTotalGemas: number; // Custo das gemas consumidas
  lucroLiquido: number; // Lucro final após todos os custos
  tokensTotais: number; // Tokens gerados + farmados
  gemasNecessariasRecompra: number; // Gemas necessárias para nova aceleração
  custoRecompra: number; // Custo em USD da recompra
  lucroFinal: number; // Lucro final após recompra das gemas
  eficienciaFarm: number; // Tokens farmados por carga utilizada
}
