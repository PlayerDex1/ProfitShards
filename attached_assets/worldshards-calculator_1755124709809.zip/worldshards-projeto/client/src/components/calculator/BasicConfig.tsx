import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Calculator } from "lucide-react";
import { CalculatorState } from "@/types/calculator";

interface BasicConfigProps {
  state: CalculatorState;
  onUpdate: (updates: Partial<CalculatorState>) => void;
}

export function BasicConfig({ state, onUpdate }: BasicConfigProps) {
  const handleChange = (field: keyof CalculatorState, value: number) => {
    onUpdate({ [field]: value });
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <h2 className="text-xl font-semibold text-slate-800 mb-6 flex items-center">
        <i className="fas fa-cog text-blue-600 mr-2"></i>
        Configuração Básica
      </h2>
      
      {/* Basic Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
        <div>
          <Label htmlFor="luck" className="text-sm font-medium text-slate-700 mb-2 block">
            Luck
          </Label>
          <Input
            id="luck"
            type="number"
            value={state.luck}
            onChange={(e) => handleChange('luck', Number(e.target.value))}
            className="border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        
        <div>
          <Label htmlFor="nfts" className="text-sm font-medium text-slate-700 mb-2 block">
            NFTs
          </Label>
          <Input
            id="nfts"
            type="number"
            value={state.nfts}
            onChange={(e) => handleChange('nfts', Number(e.target.value))}
            className="border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        
        <div>
          <Label htmlFor="vg" className="text-sm font-medium text-slate-700 mb-2 block">
            VG
          </Label>
          <Input
            id="vg"
            type="number"
            value={state.vg}
            onChange={(e) => handleChange('vg', Number(e.target.value))}
            className="border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        
        <div>
          <Label htmlFor="estrelas" className="text-sm font-medium text-slate-700 mb-2 block">
            Estrelas
          </Label>
          <Input
            id="estrelas"
            type="number"
            value={state.estrelas}
            onChange={(e) => handleChange('estrelas', Number(e.target.value))}
            className="border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        
        <div>
          <Label htmlFor="dg" className="text-sm font-medium text-slate-700 mb-2 block">
            DG
          </Label>
          <Input
            id="dg"
            type="number"
            value={state.dg}
            onChange={(e) => handleChange('dg', Number(e.target.value))}
            className="border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        
        <div>
          <Label htmlFor="dropados" className="text-sm font-medium text-slate-700 mb-2 block">
            Dropados
          </Label>
          <Input
            id="dropados"
            type="number"
            value={state.dropados}
            onChange={(e) => handleChange('dropados', Number(e.target.value))}
            className="border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
      </div>

      {/* Price Configuration */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
          <Label htmlFor="precoToken" className="text-sm font-medium text-slate-700 mb-2 block">
            Preço Token ($)
          </Label>
          <Input
            id="precoToken"
            type="number"
            step="0.001"
            value={state.precoToken}
            onChange={(e) => handleChange('precoToken', Number(e.target.value))}
            className="border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        
        <div>
          <Label htmlFor="precoGema" className="text-sm font-medium text-slate-700 mb-2 block">
            Preço Gema ($)
          </Label>
          <Input
            id="precoGema"
            type="number"
            step="0.0001"
            value={state.precoGema}
            onChange={(e) => handleChange('precoGema', Number(e.target.value))}
            className="border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
      </div>

      {/* Calculate Button */}
      <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-4 rounded-lg">
        <Calculator className="mr-2 h-4 w-4" />
        Calcular Resultados
      </Button>
    </div>
  );
}
