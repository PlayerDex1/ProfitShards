import { TrendingUp, DollarSign } from "lucide-react";
import { CalculationResults } from "@/types/calculator";

interface ResultsSectionProps {
  results: CalculationResults;
}

export function ResultsSection({ results }: ResultsSectionProps) {
  return (
    <div className="space-y-4">
      {/* Quick Stats */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
          <TrendingUp className="text-emerald-600 mr-2 h-5 w-5" />
          Resumo Rápido
        </h3>
        <div className="space-y-3">
          <div className="flex justify-between">
            <span className="text-slate-600">Eficiência/Luck:</span>
            <span className="font-semibold text-slate-800">
              {results.eficiencia.toFixed(2)}%
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-600">Energia/Shards:</span>
            <span className="font-semibold text-slate-800">
              {results.energia.toFixed(2)}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-600">Preço:</span>
            <span className="font-semibold text-slate-800">
              ${results.preco.toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      {/* Financial Summary */}
      <div className="bg-gradient-to-br from-emerald-50 to-blue-50 rounded-xl border border-emerald-200 p-6">
        <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
          <DollarSign className="text-emerald-600 mr-2 h-5 w-5" />
          Resumo Financeiro
        </h3>
        <div className="space-y-3">
          <div>
            <div className="text-sm text-slate-600">Total Ganhos</div>
            <div className="text-xl font-bold text-emerald-600">
              ${results.totalGanhos.min.toFixed(2)} a ${results.totalGanhos.max.toFixed(2)}
            </div>
          </div>
          <div>
            <div className="text-sm text-slate-600">Lucro Líquido</div>
            <div className="text-xl font-bold text-blue-600">
              ${results.lucroLiquido.min.toFixed(2)} a ${results.lucroLiquido.max.toFixed(2)}
            </div>
          </div>
          <div>
            <div className="text-sm text-slate-600">Gemas Recompradas</div>
            <div className="text-lg font-semibold text-slate-800">
              {results.gemasRecompradas.min} a {results.gemasRecompradas.max}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
