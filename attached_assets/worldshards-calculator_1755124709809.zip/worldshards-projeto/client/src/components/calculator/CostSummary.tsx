import { Receipt } from "lucide-react";
import { CalculationResults, CalculatorState } from "@/types/calculator";

interface CostSummaryProps {
  state: CalculatorState;
  results: CalculationResults;
}

export function CostSummary({ state, results }: CostSummaryProps) {
  return (
    <>
      {/* Cost Summary Section */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mb-8">
        <h2 className="text-xl font-semibold text-slate-800 mb-6 flex items-center">
          <Receipt className="text-green-600 mr-2 h-5 w-5" />
          Resumo de Gastos
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
            <div className="text-sm text-blue-600 font-medium">Investimento Inicial</div>
            <div className="text-2xl font-bold text-blue-800">$100 USD</div>
            <div className="text-sm text-blue-600">(14,000 gems)</div>
          </div>
          
          <div className="bg-orange-50 rounded-lg p-4 border border-orange-200">
            <div className="text-sm text-orange-600 font-medium">Gems Restantes</div>
            <div className="text-2xl font-bold text-orange-800">
              {results.costSummary.gemsRestantes.toLocaleString()}
            </div>
            <div className="text-sm text-orange-600">gems sobrando</div>
          </div>
          
          <div className="bg-red-50 rounded-lg p-4 border border-red-200">
            <div className="text-sm text-red-600 font-medium">Total Consumido</div>
            <div className="text-2xl font-bold text-red-800">
              {results.costSummary.totalConsumido.toLocaleString()}
            </div>
            <div className="text-sm text-red-600">gems utilizadas</div>
          </div>
          
          <div className="bg-green-50 rounded-lg p-4 border border-green-200">
            <div className="text-sm text-green-600 font-medium">Total Tokens</div>
            <div className="text-2xl font-bold text-green-800">
              {results.costSummary.totalTokens.toLocaleString()}
            </div>
            <div className="text-sm text-green-600">tokens gerados</div>
          </div>
        </div>

        <div className="mt-6 p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border border-purple-200">
          <div className="text-center">
            <div className="text-sm text-purple-600 font-medium">Total Farm (2 Recargas)</div>
            <div className="text-3xl font-bold text-purple-800">
              {results.costSummary.totalFarm.toLocaleString()}
            </div>
            <div className="text-sm text-purple-600">recursos farmados</div>
            <div className="text-xs text-purple-500 mt-2">
              Cada recarga gera 42 cargas totais
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Results Table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h2 className="text-xl font-semibold text-slate-800 mb-6 flex items-center">
          <i className="fas fa-table text-indigo-600 mr-2"></i>
          Resultados Detalhados
        </h2>
        
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50">
                <th className="px-4 py-3 text-left font-medium text-slate-700 rounded-tl-lg">Luck</th>
                <th className="px-4 py-3 text-left font-medium text-slate-700">NFTs</th>
                <th className="px-4 py-3 text-left font-medium text-slate-700">VG</th>
                <th className="px-4 py-3 text-left font-medium text-slate-700">Estrelas</th>
                <th className="px-4 py-3 text-left font-medium text-slate-700">DG</th>
                <th className="px-4 py-3 text-left font-medium text-slate-700">Dropados</th>
                <th className="px-4 py-3 text-left font-medium text-slate-700">Eficiência/Luck</th>
                <th className="px-4 py-3 text-left font-medium text-slate-700">Energia/Shards</th>
                <th className="px-4 py-3 text-left font-medium text-slate-700">Preço</th>
                <th className="px-4 py-3 text-left font-medium text-slate-700">Venda Tokens</th>
                <th className="px-4 py-3 text-left font-medium text-slate-700 rounded-tr-lg">Média Tokens</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-t border-slate-200 hover:bg-slate-50 transition-colors">
                <td className="px-4 py-3 font-medium text-slate-800">{state.luck}</td>
                <td className="px-4 py-3 text-slate-700">{state.nfts}</td>
                <td className="px-4 py-3 text-slate-700">{state.vg}</td>
                <td className="px-4 py-3 text-slate-700">{state.estrelas}</td>
                <td className="px-4 py-3 text-slate-700">{state.dg}</td>
                <td className="px-4 py-3 text-slate-700">{state.dropados}</td>
                <td className="px-4 py-3 font-medium text-emerald-600">
                  {results.eficiencia.toFixed(2)}%
                </td>
                <td className="px-4 py-3 text-slate-700">{results.energia.toFixed(2)}</td>
                <td className="px-4 py-3 font-medium text-blue-600">
                  ${results.preco.toFixed(2)}
                </td>
                <td className="px-4 py-3 text-slate-700">
                  ${(results.costSummary.totalTokens * state.precoToken).toFixed(2)}
                </td>
                <td className="px-4 py-3 font-medium text-purple-600">
                  {((results.totalGanhos.min + results.totalGanhos.max) / 2 / state.precoToken).toFixed(2)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
