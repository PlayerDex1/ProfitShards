import { TrendingUp, DollarSign, Target } from "lucide-react";
import { CalculationResults } from "@/types/calculator";

interface SimpleResultsProps {
  results: CalculationResults;
}

export function SimpleResults({ results }: SimpleResultsProps) {
  const isProfit = results.lucroFinal > 0;
  
  return (
    <div className="space-y-4">
      {/* Lucro Final - Destaque Principal */}
      <div className={`rounded-xl shadow-sm border-2 p-6 ${
        isProfit 
          ? 'bg-gradient-to-br from-green-50 to-emerald-50 border-green-200' 
          : 'bg-gradient-to-br from-red-50 to-pink-50 border-red-200'
      }`}>
        <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
          <Target className={`mr-2 h-5 w-5 ${isProfit ? 'text-green-600' : 'text-red-600'}`} />
          Lucro Líquido Final
        </h3>
        <div className="text-center">
          <div className={`text-4xl font-bold ${isProfit ? 'text-green-600' : 'text-red-600'}`}>
            ${results.lucroFinal.toFixed(2)}
          </div>
          <div className={`text-sm mt-2 ${isProfit ? 'text-green-700' : 'text-red-700'}`}>
            {isProfit ? 'Investimento Lucrativo' : 'Prejuízo no Investimento'}
          </div>
        </div>
      </div>

      {/* Resumo dos Cálculos */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
          <TrendingUp className="text-blue-600 mr-2 h-5 w-5" />
          Resumo dos Cálculos
        </h3>
        <div className="space-y-3">
          <div className="flex justify-between">
            <span className="text-slate-600">Valor Total dos Tokens:</span>
            <span className="font-semibold text-slate-800">
              ${results.valorTotalTokens.toFixed(2)}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-600">Custo das Gemas:</span>
            <span className="font-semibold text-red-600">
              -${results.custoTotalGemas.toFixed(2)}
            </span>
          </div>
          <div className="flex justify-between border-t pt-2">
            <span className="text-slate-600">Lucro Bruto:</span>
            <span className="font-semibold text-slate-800">
              ${results.lucroLiquido.toFixed(2)}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-600">Custo Recompra Gemas:</span>
            <span className="font-semibold text-red-600">
              -${results.custoRecompra.toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      {/* Métricas de Eficiência */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
          <DollarSign className="text-purple-600 mr-2 h-5 w-5" />
          Métricas de Eficiência
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 bg-purple-50 rounded-lg">
            <div className="text-sm text-purple-600">Total de Tokens</div>
            <div className="text-xl font-bold text-purple-800">
              {results.tokensTotais.toLocaleString()}
            </div>
          </div>
          <div className="text-center p-3 bg-blue-50 rounded-lg">
            <div className="text-sm text-blue-600">Eficiência Farm</div>
            <div className="text-xl font-bold text-blue-800">
              {results.eficienciaFarm.toFixed(1)} tokens/carga
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}