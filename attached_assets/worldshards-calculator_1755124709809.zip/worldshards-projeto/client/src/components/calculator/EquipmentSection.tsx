import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CalculatorState, CalculationResults } from "@/types/calculator";

interface EquipmentSectionProps {
  state: CalculatorState;
  results: CalculationResults;
  onUpdate: (
    type: keyof CalculatorState['equipment'],
    updates: Partial<CalculatorState['equipment'][typeof type]>
  ) => void;
}

interface EquipmentCardProps {
  title: string;
  icon: string;
  iconColor: string;
  gem1: number;
  gem2: number;
  aceleracao1: string;
  aceleracao2: string;
  total: number;
  tokens: number;
  tokensRecarga1: number;
  tokensRecarga2: number;
  onGem1Change: (value: number) => void;
  onGem2Change: (value: number) => void;
}

function EquipmentCard({
  title,
  icon,
  iconColor,
  gem1,
  gem2,
  aceleracao1,
  aceleracao2,
  total,
  tokens,
  tokensRecarga1,
  tokensRecarga2,
  onGem1Change,
  onGem2Change
}: EquipmentCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <h3 className="text-xl font-semibold text-slate-800 mb-6 flex items-center">
        <i className={`fas ${icon} ${iconColor} mr-2`}></i>
        {title}
      </h3>
      
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="block text-sm font-medium text-slate-700 mb-2">
              1ª Recarga (Aceleração)
            </Label>
            <Input
              value={aceleracao1}
              readOnly
              className="bg-slate-50 border-slate-300"
            />
          </div>
          <div>
            <Label className="block text-sm font-medium text-slate-700 mb-2">
              Gem
            </Label>
            <Input
              type="number"
              value={gem1}
              onChange={(e) => onGem1Change(Number(e.target.value))}
              className="border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="block text-sm font-medium text-slate-700 mb-2">
              2ª Recarga (Aceleração)
            </Label>
            <Input
              value={aceleracao2}
              readOnly
              className="bg-slate-50 border-slate-300"
            />
          </div>
          <div>
            <Label className="block text-sm font-medium text-slate-700 mb-2">
              Gem
            </Label>
            <Input
              type="number"
              value={gem2}
              onChange={(e) => onGem2Change(Number(e.target.value))}
              className="border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>

        <div className="bg-slate-50 rounded-lg p-4 space-y-3">
          <div className="flex justify-between items-center">
            <span className="font-medium text-slate-700">
              {title === 'CLAW' || title === 'ARMOR' ? 'Arma Total:' : `${title} Total:`}
            </span>
            <span className="font-bold text-slate-800">
              {total.toLocaleString()} gems
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="font-medium text-slate-700">Total Tokens:</span>
            <span className="font-bold text-blue-600">{tokens}</span>
          </div>
          <div className="text-xs text-slate-600 space-y-1">
            <div className="flex justify-between">
              <span>1ª Recarga: {gem1.toLocaleString()} gems</span>
              <span className="text-blue-500">{tokensRecarga1} tokens</span>
            </div>
            <div className="flex justify-between">
              <span>2ª Recarga: {gem2.toLocaleString()} gems</span>
              <span className="text-blue-500">{tokensRecarga2} tokens</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function EquipmentSection({ state, results, onUpdate }: EquipmentSectionProps) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <EquipmentCard
        title="CLAW"
        icon="fa-claw-marks"
        iconColor="text-red-600"
        gem1={state.equipment.claw.gem1}
        gem2={state.equipment.claw.gem2}
        aceleracao1="887+"
        aceleracao2="887+"
        total={results.equipmentTotals.claw.gems}
        tokens={results.equipmentTotals.claw.tokens}
        tokensRecarga1={results.equipmentTotals.claw.recarga1.tokens}
        tokensRecarga2={results.equipmentTotals.claw.recarga2.tokens}
        onGem1Change={(value) => onUpdate('claw', { gem1: value })}
        onGem2Change={(value) => onUpdate('claw', { gem2: value })}
      />
      
      <EquipmentCard
        title="ARMOR"
        icon="fa-shield-alt"
        iconColor="text-blue-600"
        gem1={state.equipment.armor.gem1}
        gem2={state.equipment.armor.gem2}
        aceleracao1="887+"
        aceleracao2="887+"
        total={results.equipmentTotals.armor.gems}
        tokens={results.equipmentTotals.armor.tokens}
        tokensRecarga1={results.equipmentTotals.armor.recarga1.tokens}
        tokensRecarga2={results.equipmentTotals.armor.recarga2.tokens}
        onGem1Change={(value) => onUpdate('armor', { gem1: value })}
        onGem2Change={(value) => onUpdate('armor', { gem2: value })}
      />
      
      <EquipmentCard
        title="TOOL AXE"
        icon="fa-tools"
        iconColor="text-orange-600"
        gem1={state.equipment.axe.gem1}
        gem2={state.equipment.axe.gem2}
        aceleracao1="443+"
        aceleracao2="443+"
        total={results.equipmentTotals.axe.gems}
        tokens={results.equipmentTotals.axe.tokens}
        tokensRecarga1={results.equipmentTotals.axe.recarga1.tokens}
        tokensRecarga2={results.equipmentTotals.axe.recarga2.tokens}
        onGem1Change={(value) => onUpdate('axe', { gem1: value })}
        onGem2Change={(value) => onUpdate('axe', { gem2: value })}
      />
      
      <EquipmentCard
        title="TOOL PICARETA"
        icon="fa-hammer"
        iconColor="text-purple-600"
        gem1={state.equipment.picareta.gem1}
        gem2={state.equipment.picareta.gem2}
        aceleracao1="443+"
        aceleracao2="443+"
        total={results.equipmentTotals.picareta.gems}
        tokens={results.equipmentTotals.picareta.tokens}
        tokensRecarga1={results.equipmentTotals.picareta.recarga1.tokens}
        tokensRecarga2={results.equipmentTotals.picareta.recarga2.tokens}
        onGem1Change={(value) => onUpdate('picareta', { gem1: value })}
        onGem2Change={(value) => onUpdate('picareta', { gem2: value })}
      />
    </div>
  );
}
