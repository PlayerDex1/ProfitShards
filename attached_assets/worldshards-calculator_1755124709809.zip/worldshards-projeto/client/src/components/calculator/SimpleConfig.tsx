import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Calculator, DollarSign } from "lucide-react";
import { CalculatorState } from "@/types/calculator";

interface SimpleConfigProps {
  state: CalculatorState;
  onUpdate: (updates: Partial<CalculatorState>) => void;
}

export function SimpleConfig({ state, onUpdate }: SimpleConfigProps) {
  const handleChange = (field: keyof CalculatorState, value: number) => {
    onUpdate({ [field]: value });
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <h2 className="text-xl font-semibold text-slate-800 mb-6 flex items-center">
        <DollarSign className="text-green-600 mr-2 h-5 w-5" />
        Configuração de Investimento
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        <div>
          <Label htmlFor="investimentoInicial" className="text-sm font-medium text-slate-700 mb-2 block">
            Investimento Inicial (USD)
          </Label>
          <Input
            id="investimentoInicial"
            type="number"
            value={state.investimentoInicial}
            onChange={(e) => handleChange('investimentoInicial', Number(e.target.value))}
            className="border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500"
          />
        </div>
        
        <div>
          <Label htmlFor="gemasIniciais" className="text-sm font-medium text-slate-700 mb-2 block">
            Gems Compradas
          </Label>
          <Input
            id="gemasIniciais"
            type="number"
            value={state.gemasIniciais}
            onChange={(e) => handleChange('gemasIniciais', Number(e.target.value))}
            className="border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500"
          />
        </div>
        
        <div>
          <Label htmlFor="gemasRestantes" className="text-sm font-medium text-slate-700 mb-2 block">
            Gems Restantes
          </Label>
          <Input
            id="gemasRestantes"
            type="number"
            value={state.gemasRestantes}
            onChange={(e) => handleChange('gemasRestantes', Number(e.target.value))}
            className="border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500"
          />
        </div>
        
        <div>
          <Label htmlFor="totalConsumido" className="text-sm font-medium text-slate-700 mb-2 block">
            Gems Consumidas
          </Label>
          <Input
            id="totalConsumido"
            type="number"
            value={state.totalConsumido}
            onChange={(e) => handleChange('totalConsumido', Number(e.target.value))}
            className="border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500"
          />
        </div>
        
        <div>
          <Label htmlFor="totalTokensGerados" className="text-sm font-medium text-slate-700 mb-2 block">
            Tokens dos Equipamentos
          </Label>
          <Input
            id="totalTokensGerados"
            type="number"
            value={state.totalTokensGerados}
            onChange={(e) => handleChange('totalTokensGerados', Number(e.target.value))}
            className="border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500"
          />
        </div>
        
        <div>
          <Label htmlFor="tokensFarmados" className="text-sm font-medium text-slate-700 mb-2 block">
            Tokens Farmados
          </Label>
          <Input
            id="tokensFarmados"
            type="number"
            value={state.tokensFarmados}
            onChange={(e) => handleChange('tokensFarmados', Number(e.target.value))}
            className="border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500"
          />
        </div>
        
        <div>
          <Label htmlFor="cargasUtilizadas" className="text-sm font-medium text-slate-700 mb-2 block">
            Cargas Utilizadas
          </Label>
          <Input
            id="cargasUtilizadas"
            type="number"
            value={state.cargasUtilizadas}
            onChange={(e) => handleChange('cargasUtilizadas', Number(e.target.value))}
            className="border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500"
          />
        </div>
        
        <div>
          <Label htmlFor="precoToken" className="text-sm font-medium text-slate-700 mb-2 block">
            Preço Token (USD)
          </Label>
          <Input
            id="precoToken"
            type="number"
            step="0.001"
            value={state.precoToken}
            onChange={(e) => handleChange('precoToken', Number(e.target.value))}
            className="border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500"
          />
        </div>
        
        <div>
          <Label htmlFor="precoGema" className="text-sm font-medium text-slate-700 mb-2 block">
            Preço Gema (USD)
          </Label>
          <Input
            id="precoGema"
            type="number"
            step="0.0001"
            value={state.precoGema}
            onChange={(e) => handleChange('precoGema', Number(e.target.value))}
            className="border-slate-300 focus:ring-2 focus:ring-green-500 focus:border-green-500"
          />
        </div>
      </div>

      <Button className="w-full bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-4 rounded-lg">
        <Calculator className="mr-2 h-4 w-4" />
        Calcular Lucro Líquido
      </Button>
    </div>
  );
}