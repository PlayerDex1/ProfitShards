# Calculadora de Lucro - Worldshards

Uma calculadora web interativa para calcular custos, lucros e eficiência de equipamentos no jogo Worldshards.

## 🚀 Deploy Online

Esta aplicação está configurada para deploy estático e pode ser hospedada gratuitamente em:

- **Netlify**: Arraste a pasta `dist` após fazer o build
- **Vercel**: Conecte seu GitHub e deploy automático
- **GitHub Pages**: Ative Pages nas configurações do repositório

## 📋 Como usar

### 1. Clone o repositório
```bash
git clone https://github.com/seu-usuario/worldshards-calculator.git
cd worldshards-calculator
```

### 2. Instale as dependências
```bash
npm install
```

### 3. Execute localmente
```bash
npm run dev
```

### 4. Gere build para produção
```bash
npm run build
```

O build será criado na pasta `dist/public` e estará pronto para deploy estático.

## 🌐 Deploy no Netlify

1. Faça o build: `npm run build`
2. Vá em [netlify.com](https://netlify.com)
3. Arraste a pasta `dist/public` na área de deploy
4. Sua calculadora estará online!

## 🎮 Sobre

Calculadora focada em:
- Cálculo de investimento em gemas
- Geração de tokens por equipamentos
- Eficiência de farming
- Lucro líquido após recompra de gemas

## 🛠️ Tecnologias

- React 18 + TypeScript
- Tailwind CSS + Shadcn/ui
- Vite (build tool)
- Hospedagem estática (sem servidor)

## 📊 Funcionalidades

- ✅ Cálculo automático de lucro líquido
- ✅ Campos editáveis para personalização
- ✅ Interface responsiva
- ✅ Deploy estático (gratuito)
- ✅ Sem necessidade de servidor