# 🚀 Guia de Deploy - GitHub + Netlify

Siga estes passos para colocar sua calculadora online **gratuitamente**:

## 1️⃣ Preparar para GitHub

### Arquivos que já estão prontos:
- ✅ `README.md` - Documentação do projeto
- ✅ `.gitignore` - Arquivos que não vão pro GitHub
- ✅ `netlify.toml` - Configuração automática do Netlify
- ✅ Build funcionando - Pasta `dist/public` criada

## 2️⃣ Subir para GitHub

### Opção A: Usando o site do GitHub
1. Vá em [github.com](https://github.com) e faça login
2. Clique em "New repository"
3. Nome: `worldshards-calculator`
4. Mantenha público (para GitHub Pages grátis)
5. Clique em "Create repository"

### Opção B: Usando linha de comando (se souber)
```bash
git init
git add .
git commit -m "Calculadora Worldshards pronta"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/worldshards-calculator.git
git push -u origin main
```

## 3️⃣ Deploy no Netlify (GRATUITO)

### Método 1: Drag & Drop (Mais Fácil)
1. Execute: `npm run build`
2. Vá em [netlify.com](https://netlify.com)
3. Faça login (pode usar GitHub)
4. Arraste a pasta `dist/public` na área de deploy
5. **Pronto! URL online em segundos**

### Método 2: Conectar GitHub (Deploy Automático)
1. No Netlify, clique "New site from Git"
2. Conecte seu GitHub
3. Escolha o repositório `worldshards-calculator`
4. **Deploy automático a cada commit!**

## 4️⃣ Resultado Final

Sua calculadora estará online com:
- ✅ URL permanente (ex: `nome-do-site.netlify.app`)
- ✅ HTTPS automático
- ✅ Deploy instantâneo
- ✅ **Totalmente gratuito**
- ✅ Funciona em qualquer dispositivo

## 🎯 Vantagens

- **GitHub**: Backup seguro do código
- **Netlify**: Hospedagem gratuita ilimitada
- **Deploy automático**: Atualizações instantâneas
- **Sem servidor**: Mais rápido e barato (grátis!)

## 📱 Testado e Funcionando

Sua calculadora já está otimizada para:
- 📊 Cálculos corretos de lucro
- 💎 Conversão gemas/tokens
- 📈 Interface responsiva
- ⚡ Carregamento rápido